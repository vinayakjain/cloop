#!usr/bin/python
import commands,os
commands.getstatusoutput('iscsiadm --mode discoverydb --type sendtargets --portal 10.0.0.1  --discover')
commands.getstatusoutput('iscsiadm --mode node --targetname  lomn --portal 10.0.0.1:3260 --login')
os.system('fdisk -l')