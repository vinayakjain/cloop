#!/bin/bash
virt-viewer 10.0.0.1:5904