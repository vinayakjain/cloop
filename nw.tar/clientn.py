#!/usr/bin/python

import os,commands



commands.getstatusoutput("yum install nfs-utils")
p=commands.getstatusoutput("systemctl restart nfs-utils")
if p[0]!=0:
	print "please check the nfs support"
	exit()
def lb():
	
	w=commands.getstatusoutput("sudo mkdir /media/123")
while w[0]!=0 :
		a=raw_input("enter name of folder ")
		w=commands.getstatusoutput(" sudo mkdir /media/"+a)
else :	
		os.system(" sudo mount 10.0.0.1:/media/{0}  /media/{1}".format(b,a))
		

