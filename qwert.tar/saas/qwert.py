#!/usr/bin/python
import commands,time
commands.getstatusoutput('sshpass -p qwertyuiop ssh -X -l qwert 10.0.0.1 firefox')
raw_input()