#!/usr/bin/python
import commands
commands.getstatusoutput('mkdir /objs')
commands.getstatusoutput('chmod -R 777 /objs')
a=commands.getstatusoutput('mount 10.0.0.1:/media/wew /objs')
print a
commands.getstatusoutput('df -hT')
raw_input()