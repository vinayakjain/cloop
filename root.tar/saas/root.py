#!/usr/bin/python
import commands,time
commands.getstatusoutput('sshpass -p q ssh -x -l root 10.0.0.1 firefox')
raw_input()