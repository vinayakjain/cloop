#!/usr/bin/python
import commands
commands.getstatusoutput('mkdir /objs')
commands.getstatusoutput('chmod -R 777 /objs')
a=commands.getstatusoutput('mount 10.0.0.1:/media/rohang /objs')
print adf -hT
raw_input()