#!usr/bin/python
import commands,os,time
commands.getstatusoutput('iscsiadm --mode discoverydb --type sendtargets --portal 10.0.0.1  --discover')
commands.getstatusoutput('iscsiadm --mode node --targetname  lkmi --portal 10.0.0.1:3260 --login')
os.system('fdisk -l')
time.sleep(5)